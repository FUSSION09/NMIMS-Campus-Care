# Campus Care Backend (Node + Express + MySQL + JWT)

This backend powers the frontend pages in `Frontend 2/` by providing REST APIs for:
- Student registration + login (JWT)
- Medical appointment bookings
- Counseling bookings
- Feedback submission
- Support group joining

## 1) Prerequisites
- Node.js
- MySQL server

## 2) Configure environment
1. Copy `.env.example` to `.env`
2. Update `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and `JWT_SECRET`

## 3) Create database + tables
Run this in MySQL (adjust password/host if needed):

```sql
CREATE DATABASE IF NOT EXISTS campus_care;
USE campus_care;
SOURCE db/schema.sql;
```

## 4) Run the server
```bash
cd backend
npm run dev
```
Server starts at `http://localhost:3000`.

## API Routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET  /api/me/` (requires `Authorization: Bearer <token>`)
- `GET  /api/me/appointments` (student only, requires token)
- `POST /api/medical-appointments` (requires token)
- `POST /api/counseling-appointments` (requires token)
- `POST /api/feedback` (token optional)
- `POST /api/support-groups/join` (requires token)

