-- Campus Care schema (MySQL)
-- Run after creating the database (or adjust DB_NAME accordingly).

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sap_id VARCHAR(20) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student', 'doctor', 'admin') NOT NULL DEFAULT 'student',
  -- Doctors (including counselors) use this to determine which appointments they see.
  specialization VARCHAR(100) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS medical_appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_user_id INT NOT NULL,
  doctor_name VARCHAR(100) NOT NULL,
  appt_date DATE NOT NULL,
  appt_time VARCHAR(50) NOT NULL,
  reason TEXT NULL,
  status ENUM('Confirmed', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS counseling_bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_user_id INT NOT NULL,
  counselor_name VARCHAR(100) NOT NULL,
  appt_date DATE NOT NULL,
  slot VARCHAR(60) NOT NULL,
  status ENUM('Confirmed', 'Cancelled', 'Completed') NOT NULL DEFAULT 'Confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_user_id INT NULL,
  rating ENUM('Bad','OK','Good','Excellent') NOT NULL,
  category VARCHAR(50) NOT NULL,
  name VARCHAR(100) NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_groups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  group_name VARCHAR(100) NOT NULL UNIQUE,
  next_meeting_day VARCHAR(20) NULL,
  next_meeting_time VARCHAR(30) NULL,
  location VARCHAR(100) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS support_group_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  group_id INT NOT NULL,
  student_user_id INT NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (group_id, student_user_id),
  FOREIGN KEY (group_id) REFERENCES support_groups(id) ON DELETE CASCADE,
  FOREIGN KEY (student_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed support groups (matches the frontend buttons)
INSERT INTO support_groups (group_name, next_meeting_day, next_meeting_time, location)
VALUES
  ('Academic Pressure', 'Tuesday', '5:00 PM - 6:00 PM', 'Room 302 / Zoom'),
  ('Hostel Life', 'Thursday', '7:00 PM - 8:00 PM', 'Hostel Common Room'),
  ('Career Stress', 'Saturday', '11:00 AM - 12:30 PM', 'Placement Cell Hall')
ON DUPLICATE KEY UPDATE
  next_meeting_day = VALUES(next_meeting_day),
  next_meeting_time = VALUES(next_meeting_time),
  location = VALUES(location);

