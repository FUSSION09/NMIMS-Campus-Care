const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const dotenv = require("dotenv");

// --- ROUTE IMPORTS ---
const authRoutes = require("./routes/auth");
const meRoutes = require("./routes/me");
const adminRoutes = require("./routes/admin");
const appointmentRoutes = require("./routes/appointments"); 
// Removed medical/counseling imports as they are now handled by appointmentRoutes

dotenv.config();
const app = express();

// --- MIDDLEWARE ---
app.use(helmet()); 
// CORS configured for local development
app.use(cors({ origin: "*", methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"] }));
app.use(express.json());
app.use(morgan("dev")); 

// --- API ROUTES ---

// 1. Authentication & User Profile
app.use("/api/auth", authRoutes);
app.use("/api/me", meRoutes);

// 2. Appointments (Unified Logic)
// All these point to appointments.js to match your single database table
app.use("/api/appointments", appointmentRoutes);
app.use("/api/medical", appointmentRoutes); 
app.use("/api/counseling", appointmentRoutes);

// 3. Admin Panel (Stats, User Management, Global History)
app.use("/api/admin", adminRoutes);

// --- 404 HANDLER ---
app.use((req, res) => {
    console.log(`[404 Error] Not Found: ${req.method} ${req.url}`);
    res.status(404).json({ error: "Route not found on server" });
});

// --- DATABASE CONNECTION & STARTUP ---
const { testDbConnection } = require("./db"); 
const port = process.env.PORT || 3000;

testDbConnection()
    .then(() => {
        app.listen(port, () => {
            console.log("-----------------------------------------");
            console.log(`🚀 NMIMS Campus Care Backend: http://localhost:${port}`);
            console.log("Admin API: http://localhost:3000/api/admin/appointments");
            console.log("-----------------------------------------");
        });
    })
    .catch((err) => {
        console.error("[CRITICAL] DB Connection failed:", err.message);
        process.exit(1);
    });