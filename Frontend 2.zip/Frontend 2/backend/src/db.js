const mysql = require("mysql2/promise");
require("dotenv").config();

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  // MySQL often requires a password; leaving this empty will cause "Access denied".
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "campus_care",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  // Improve reliability for pooled connections
  timezone: "Z",
});

module.exports = {
  pool,
  async testDbConnection() {
    const passwordProvided = Boolean(process.env.DB_PASSWORD);
    if (!passwordProvided) {
      // eslint-disable-next-line no-console
      console.warn(
        "[DB] DB_PASSWORD is empty/missing. If your MySQL root/user requires a password, requests will fail."
      );
    }
    // eslint-disable-next-line no-unused-vars
    const conn = await pool.getConnection();
    try {
      await conn.query("SELECT 1 AS ok");
    } finally {
      conn.release();
    }
  },
};

