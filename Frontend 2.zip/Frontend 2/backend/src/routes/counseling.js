const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

/**
 * POST /api/counseling/
 * Handles booking a counseling session.
 */
router.post(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    // 1. Security Check
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Only students can create counseling bookings" });
    }

    // 2. Data Extraction (Mapping 'time' from frontend to 'slot' for DB)
    const { student_sap, specialistName, date, time, reason, status } = req.body || {};

    // 3. Validation
    if (!specialistName || !date || !time) {
      return res.status(400).json({ error: "Counselor name, date, and time slot are required" });
    }

    // 4. SAP ID Consistency check
    const tokenSap = req.user.sapId || req.user.sap_id;
    if (student_sap && String(student_sap).trim() !== String(tokenSap)) {
      return res.status(403).json({ error: "SAP ID mismatch with logged-in user" });
    }

    // 5. Status Handling
    const apptStatus = status || "Confirmed";
    const allowed = new Set(["Confirmed", "Cancelled", "Completed", "Scheduled"]);
    const finalStatus = allowed.has(apptStatus) ? apptStatus : "Confirmed";

    try {
      // 6. Database Insertion
      // We use 'slot' to match your counseling_bookings table schema
      const [result] = await pool.query(
        `INSERT INTO counseling_bookings 
          (student_user_id, counselor_name, appt_date, slot, reason, status) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          req.user.userId, 
          String(specialistName).trim(), 
          date, 
          String(time).trim(), 
          reason || null, 
          finalStatus
        ]
      );

      return res.status(201).json({ 
        success: true,
        id: result.insertId, 
        status: finalStatus,
        message: "Counseling session booked!" 
      });

    } catch (dbError) {
      console.error("COUNSELING DB ERROR:", dbError.message);
      return res.status(500).json({ 
        error: "Database insertion failed", 
        details: dbError.message 
      });
    }
  })
);

module.exports = router;