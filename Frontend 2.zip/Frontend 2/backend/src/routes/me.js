const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

/**
 * GET /api/me/
 * Fetches the currently logged-in user's profile info.
 */
router.get(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { userId } = req.user;

    const [rows] = await pool.query(
      "SELECT id, sap_id, full_name, role, created_at FROM users WHERE id = ? LIMIT 1",
      [userId]
    );

    if (!rows.length) {
      return res.status(404).json({ error: "User not found" });
    }

    const u = rows[0];
    return res.json({
      user: {
        id: u.id,
        sap_id: u.sap_id,
        full_name: u.full_name,
        role: u.role,
        created_at: u.created_at,
      },
    });
  })
);

/**
 * GET /api/me/appointments
 * Fetches combined medical and counseling appointments for the student.
 */
router.get(
  "/appointments",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { userId, role } = req.user;

    // Security check to ensure only students access this dashboard data
    if (role !== "student") {
      return res.status(403).json({ error: "Only students can view their appointments" });
    }

    let medical = [];
    let counseling = [];

    // 1. Fetch Medical Appointments 
    // Uses 'doctor_name' and 'reason' as confirmed in your database logs
    try {
      const [medRows] = await pool.query(
        `SELECT 
            id, appt_date, appt_time, doctor_name AS provider_name,
            reason, status, 'medical' AS type
         FROM medical_appointments 
         WHERE student_user_id = ?
         ORDER BY appt_date DESC LIMIT 10`,
        [userId]
      );
      medical = medRows;
    } catch (err) {
      console.error("Error fetching medical appointments:", err.message);
    }

    // 2. Fetch Counseling Bookings
    // Uses 'slot' and 'counselor_name' as confirmed in your database logs
    try {
      const [counRows] = await pool.query(
        `SELECT 
            id, appt_date, slot AS appt_time, counselor_name AS provider_name,
            reason, status, 'counseling' AS type
         FROM counseling_bookings 
         WHERE student_user_id = ?
         ORDER BY appt_date DESC LIMIT 10`,
        [userId]
      );
      counseling = counRows;
    } catch (err) {
      console.error("Error fetching counseling appointments:", err.message);
    }

    // 3. Combine and Sort by Date (Newest First)
    const combined = [...medical, ...counseling].sort((a, b) => {
      return new Date(b.appt_date) - new Date(a.appt_date);
    });

    // Return the latest 10 combined records
    return res.json({ appointments: combined.slice(0, 10) });
  })
);

module.exports = router;