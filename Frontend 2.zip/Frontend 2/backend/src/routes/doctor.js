const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

/**
 * GET: All Appointments for the logged-in Doctor
 * Fetches everything (Pending, Completed, Cancelled) so the 
 * frontend can split them into "Queue" and "History" tabs.
 */
router.get("/appointments", requireAuth, asyncHandler(async (req, res) => {
    // 1. Security Check
    if (req.user.role !== "doctor") {
        return res.status(403).json({ error: "Access denied. Doctors only." });
    }

    try {
        // 2. Get exact doctor name from the users table using the ID from the token
        const [doctorRows] = await pool.query(
            "SELECT full_name FROM users WHERE id = ?", 
            [req.user.userId]
        );

        if (doctorRows.length === 0) {
            return res.status(404).json({ error: "Doctor profile not found in database." });
        }

        const drFullName = doctorRows[0].full_name;
        
        // 3. Create a "clean" name version to handle cases where 
        // student booked "Iyer" instead of "Dr. Iyer"
        const cleanName = drFullName.replace(/^(Dr\.|Mr\.|Ms\.|Mrs\.)\s+/i, "").trim();

        console.log(`[DEBUG] Logged in as: "${drFullName}" | Searching database for: "${drFullName}" or "${cleanName}"`);

        // 4. FETCH ALL RECORDS
        // We use LEFT JOIN so we get the Student's name from the users table
        const sql = `
            SELECT 
                a.id, 
                a.category, 
                u.full_name AS student_name, 
                a.sap_id AS student_sap, 
                a.appointment_time AS appt_time, 
                a.appointment_date AS appt_date, 
                a.status 
            FROM appointments a
            LEFT JOIN users u ON u.sap_id = a.sap_id
            WHERE (a.doctor_name LIKE ? OR a.doctor_name LIKE ?)
            ORDER BY a.appointment_date DESC, a.appointment_time ASC`;
            
        const [rows] = await pool.query(sql, [`%${drFullName}%`, `%${cleanName}%`]);
        
        console.log(`[SUCCESS] Found ${rows.length} total records for this doctor.`);
        
        // Send the data to the frontend
        res.json({ appointments: rows });

    } catch (err) {
        console.error("DATABASE FETCH ERROR:", err.message);
        res.status(500).json({ error: "Server error fetching appointment list" });
    }
}));

/**
 * PATCH: Update Appointment Status
 * Used when doctor clicks "Treated" (Completed) or "No Show" (Cancelled)
 */
router.patch("/status", requireAuth, asyncHandler(async (req, res) => {
    const { id, status } = req.body;

    // Validate the incoming status
    const validStatuses = ['Completed', 'Cancelled', 'Pending', 'Confirmed'];
    if (!id || !validStatuses.includes(status)) {
        return res.status(400).json({ error: "Valid ID and status ('Completed' or 'Cancelled') required" });
    }

    try {
        const [result] = await pool.query(
            "UPDATE appointments SET status = ? WHERE id = ?", 
            [status, id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Appointment record not found." });
        }

        console.log(`[UPDATE] Appointment ID ${id} set to ${status}`);
        res.json({ success: true, message: `Status successfully updated to ${status}` });
    } catch (err) {
        console.error("STATUS UPDATE ERROR:", err.message);
        res.status(500).json({ error: "Failed to update status in database." });
    }
}));

module.exports = router;