const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

/**
 * POST /api/medical/
 * Handles booking a medical appointment.
 */
router.post(
  "/",
  requireAuth,
  asyncHandler(async (req, res) => {
    // 1. Security Check: Only students can book
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Access denied: Only students can create appointments" });
    }

    // 2. Data Extraction
    const { student_sap, doctor_name, appt_date, appt_time, reason, status } = req.body || {};

    // 3. Validation: Core fields must exist
    if (!doctor_name || !appt_date || !appt_time) {
      return res.status(400).json({ error: "Doctor name, appointment date, and time slot are required" });
    }

    // 4. SAP ID Consistency 
    // Uses optional chaining to handle different token property names (sapId vs sap_id)
    const tokenSap = req.user.sapId || req.user.sap_id;
    if (student_sap && String(student_sap).trim() !== String(tokenSap)) {
      return res.status(403).json({ error: "Security Alert: SAP ID mismatch with logged-in user" });
    }

    // 5. Status Sanitization
    const allowedStatuses = ["Scheduled", "Confirmed", "Cancelled", "Completed"];
    const finalStatus = allowedStatuses.includes(status) ? status : "Scheduled";

    try {
      // 6. Database Insertion
      // Note: We use req.user.userId which is extracted from the JWT in requireAuth
      const [result] = await pool.query(
        `INSERT INTO medical_appointments 
         (student_user_id, doctor_name, appt_date, appt_time, reason, status) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          req.user.userId, 
          String(doctor_name).trim(), 
          appt_date, 
          String(appt_time).trim(), 
          reason ? String(reason).trim() : null, 
          finalStatus
        ]
      );

      return res.status(201).json({ 
        success: true, 
        message: "Medical appointment booked successfully",
        appointmentId: result.insertId 
      });

    } catch (dbError) {
      // Log full error to backend console for debugging
      console.error("MEDICAL BOOKING DB ERROR:", dbError);

      // Check for specific duplicate slot errors (Optional enhancement)
      if (dbError.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ error: "This time slot is already taken for the selected date." });
      }

      return res.status(500).json({ 
        error: "Internal database error during booking", 
        details: dbError.message 
      });
    }
  })
);

module.exports = router;