const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

/**
 * Middleware to verify Admin role
 */
function requireAdmin(req, res, next) {
    // Ensure the user object exists and role is admin
    if (!req.user || req.user.role !== "admin") {
        return res.status(403).json({ error: "Access Denied: Administrative privileges required" });
    }
    next();
}

/**
 * 1. GET ADMIN STATS
 */
router.get("/stats", requireAuth, requireAdmin, asyncHandler(async (req, res) => {
    // Count Users
    const [students] = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'student'");
    const [doctors] = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'doctor'");
    
    // Count Appointments 
    // FIXED: Using LIKE to catch 'Mental Support' or 'Mental health' more reliably
    const [medAppts] = await pool.query("SELECT COUNT(*) as count FROM appointments WHERE category = 'Medical'");
    const [counAppts] = await pool.query("SELECT COUNT(*) as count FROM appointments WHERE category LIKE 'Mental%'");

    res.json({
        totalStudents: students[0].count,
        totalDoctors: doctors[0].count,
        totalMedical: medAppts[0].count,
        totalCounseling: counAppts[0].count
    });
}));

/**
 * 2. GET ALL USERS
 */
router.get("/users", requireAuth, requireAdmin, asyncHandler(async (req, res) => {
    // Corrected columns based on your 'DESCRIBE users' screenshot
    const [rows] = await pool.query(
        "SELECT id, full_name, email, role, specialization, sap_id FROM users ORDER BY role DESC"
    );
    res.json({ users: rows });
}));

/**
 * 3. GET ALL APPOINTMENTS
 */
router.get("/appointments", requireAuth, requireAdmin, asyncHandler(async (req, res) => {
    // Matches your 'DESCRIBE appointments' fields exactly
    const sql = `
      SELECT id, sap_id, category, doctor_name, appointment_date, appointment_time, status 
      FROM appointments 
      ORDER BY appointment_date DESC
    `;
    const [rows] = await pool.query(sql);
    res.json({ appointments: rows });
}));

/**
 * 4. DELETE USER
 */
router.delete("/users/:id", requireAuth, requireAdmin, asyncHandler(async (req, res) => {
    const [result] = await pool.query("DELETE FROM users WHERE id = ?", [req.params.id]);
    
    if (result.affectedRows === 0) {
        return res.status(404).json({ error: "User not found" });
    }
    res.json({ success: true, message: "User deleted successfully" });
}));

/**
 * 5. PATCH APPOINTMENT STATUS
 */
router.patch("/appointments/status", requireAuth, requireAdmin, asyncHandler(async (req, res) => {
    const { id, status } = req.body; 
    
    if (!id || !status) {
        return res.status(400).json({ error: "Missing required fields (id, status)" });
    }

    // Direct update to your 'appointments' table
    const [result] = await pool.query("UPDATE appointments SET status = ? WHERE id = ?", [status, id]);
    
    if (result.affectedRows === 0) {
        return res.status(404).json({ error: "Appointment record not found" });
    }

    res.json({ success: true, message: `Status updated to ${status}` });
}));

module.exports = router;