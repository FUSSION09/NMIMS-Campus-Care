const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

router.post(
  "/join",
  requireAuth,
  asyncHandler(async (req, res) => {
    if (req.user.role !== "student") {
      return res.status(403).json({ error: "Only students can join support groups" });
    }

    const { groupName } = req.body || {};
    if (!groupName) return res.status(400).json({ error: "groupName is required" });

    const gn = String(groupName).trim();

    const [groups] = await pool.query(
      "SELECT id FROM support_groups WHERE group_name = ? LIMIT 1",
      [gn]
    );
    if (!groups.length) {
      return res.status(404).json({ error: "Support group not found" });
    }
    const groupId = groups[0].id;

    const [existing] = await pool.query(
      "SELECT id FROM support_group_members WHERE group_id = ? AND student_user_id = ? LIMIT 1",
      [groupId, req.user.userId]
    );

    if (existing.length) {
      return res.json({ joined: true, id: existing[0].id });
    }

    const [result] = await pool.query(
      "INSERT INTO support_group_members (group_id, student_user_id) VALUES (?, ?)",
      [groupId, req.user.userId]
    );

    return res.status(201).json({ joined: true, id: result.insertId });
  })
);

module.exports = router;

