const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

function signToken(payload) {
    // Make sure your .env has JWT_SECRET, otherwise it uses the fallback
    const secret = process.env.JWT_SECRET || "dev_jwt_secret_change_me";
    return jwt.sign(payload, secret, { expiresIn: "7d" });
}

// --- LOGIN ROUTE ---
router.post("/login", asyncHandler(async (req, res) => {
    const role = req.body.role ? String(req.body.role).trim() : null;
    const loginUser = req.body.loginUser ? String(req.body.loginUser).trim() : null;
    const password = req.body.password ? String(req.body.password).trim() : null;

    console.log("==========================================");
    console.log(`[LOGIN ATTEMPT] User: ${loginUser}, Role: ${role}`);

    if (!role || !loginUser || !password) {
        return res.status(400).json({ error: "Missing required fields" });
    }

    // Lookup user by Email OR SAP ID
    const [rows] = await pool.query(
        "SELECT * FROM users WHERE email = ? OR sap_id = ? LIMIT 1",
        [loginUser, loginUser]
    );

    if (rows.length === 0) {
        console.log(`[AUTH FAIL] No user found: ${loginUser}`);
        return res.status(401).json({ error: "Invalid credentials" });
    }

    const user = rows[0];

    // Check Role (Case-sensitive check)
    if (user.role.toLowerCase() !== role.toLowerCase()) {
        console.log(`[AUTH FAIL] Role mismatch. DB: ${user.role}, Sent: ${role}`);
        return res.status(401).json({ error: "Invalid role selected" });
    }

    // Check Password
    const isBcryptMatch = await bcrypt.compare(password, user.password_hash);
    
    // UPDATED: Master password is now 'password123' to match your request
    const isMasterMatch = (password === "password123"); 
    
    console.log(`[AUTH DEBUG] Bcrypt: ${isBcryptMatch}, Master: ${isMasterMatch}`);

    if (!isBcryptMatch && !isMasterMatch) {
        return res.status(401).json({ error: "Invalid password" });
    }

    console.log(`[AUTH SUCCESS] Logged in: ${user.full_name}`);

    // IMPORTANT: We include sap_id in the token so the Dashboard knows who this is
    const token = signToken({ 
        userId: user.id, 
        sap_id: user.sap_id, 
        role: user.role,
        full_name: user.full_name 
    });
    
    res.json({
        token,
        user: { 
            id: user.id, 
            full_name: user.full_name, 
            role: user.role,
            sap_id: user.sap_id 
        }
    });
}));

// --- REGISTER ROUTE ---
router.post("/register", asyncHandler(async (req, res) => {
    const { full_name, sap_id, email, password, role, specialization } = req.body;

    if (!full_name || !sap_id || !email || !password || !role) {
        return res.status(400).json({ error: "All fields are required" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const [result] = await pool.query(
        "INSERT INTO users (full_name, sap_id, email, password_hash, role, specialization) VALUES (?, ?, ?, ?, ?, ?)",
        [full_name, sap_id, email, passwordHash, role, specialization || null]
    );

    const token = signToken({ userId: result.insertId, sap_id, role });

    res.status(201).json({
        success: true,
        token,
        user: { id: result.insertId, full_name, role }
    });
}));

module.exports = router;