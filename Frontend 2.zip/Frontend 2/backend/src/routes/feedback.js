const express = require("express");
const jwt = require("jsonwebtoken");

const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

function getUserFromOptionalToken(req) {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) return null;
  try {
    const secret = process.env.JWT_SECRET || "dev_jwt_secret_change_me";
    const payload = jwt.verify(token, secret);
    return payload; // { userId, sap_id, role }
  } catch {
    return null;
  }
}

router.post(
  "/",
  asyncHandler(async (req, res) => {
    const { rating, category, name, comment } = req.body || {};
    if (!rating || !category || !comment) {
      return res.status(400).json({ error: "rating, category, comment are required" });
    }

    const allowedRatings = new Set(["Bad", "OK", "Good", "Excellent"]);
    const finalRating = allowedRatings.has(rating) ? rating : "Good";

    const userPayload = getUserFromOptionalToken(req);
    const studentUserId = userPayload && userPayload.role === "student" ? userPayload.userId : null;

    const [result] = await pool.query(
      `INSERT INTO feedback
        (student_user_id, rating, category, name, comment)
       VALUES (?, ?, ?, ?, ?)`,
      [studentUserId, finalRating, String(category).trim(), name ? String(name).trim() : null, String(comment).trim()]
    );

    return res.status(201).json({ id: result.insertId });
  })
);

module.exports = router;

