const express = require("express");

const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");

const router = express.Router();

router.get(
  "/doctors",
  asyncHandler(async (req, res) => {
    const [rows] = await pool.query(
      "SELECT id, full_name, email, specialization FROM users WHERE role = 'doctor' ORDER BY specialization, id"
    );

    const doctors = rows.map((d) => {
      const specialization = d.specialization;
      const fullName = d.full_name;

      let provider_name;
      if (specialization === "General Doctor") {
        provider_name = `Dr. ${fullName}`;
      } else if (String(specialization || "").includes("Counselor")) {
        provider_name = `Ms. ${fullName}`;
      } else {
        // Fallback: still return a usable provider_name.
        provider_name = String(fullName).trim();
      }

      return {
        id: d.id,
        full_name: fullName,
        email: d.email,
        specialization,
        provider_name,
      };
    });

    return res.json({ doctors });
  })
);

module.exports = router;

