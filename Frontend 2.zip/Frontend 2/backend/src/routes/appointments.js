const express = require("express");
const router = express.Router();
const { pool } = require("../db");
const { asyncHandler } = require("../utils/asyncHandler");
const { requireAuth } = require("../middleware/auth");

/**
 * @route   POST /api/medical/book
 * @desc    Create a new appointment
 * @access  Private
 */
router.post("/book", asyncHandler(async (req, res) => {
    // Destructure exactly what the HTML frontend is sending
    const { 
        sap_id, 
        service_type, 
        appointment_date, 
        appointment_time, 
        specialistName 
    } = req.body;

    // VALIDATION: Matches the variables above
    if (!sap_id || !service_type || !appointment_date || !appointment_time || !specialistName) {
        return res.status(400).json({ 
            error: "Please fill all fields. Check if Specialist and Time are selected." 
        });
    }

    // DATABASE INSERT
    // Mapping: service_type -> category | specialistName -> doctor_name
    try {
        const [result] = await pool.query(
            "INSERT INTO appointments (sap_id, category, doctor_name, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?, ?, 'Pending')",
            [sap_id, service_type, specialistName, appointment_date, appointment_time]
        );

        return res.status(201).json({ 
            success: true, 
            message: "Appointment booked successfully!",
            bookingId: result.insertId 
        });
    } catch (err) {
        console.error("Database Error:", err);
        return res.status(500).json({ error: "Internal Database Error" });
    }
}));

/**
 * @route   GET /api/medical/my-bookings
 * @desc    Get all appointments for the logged-in student
 * @access  Private
 */
router.get("/my-bookings", requireAuth, asyncHandler(async (req, res) => {
    const sapId = req.user.sap_id; 
    
    const [rows] = await pool.query(
        "SELECT id, category, doctor_name, appointment_date, appointment_time, status FROM appointments WHERE sap_id = ? ORDER BY appointment_date DESC",
        [sapId]
    );
    
    res.json({ appointments: rows });
}));

/**
 * @route   PATCH /api/medical/cancel/:id
 * @desc    Cancel a pending appointment
 * @access  Private
 */
router.patch("/cancel/:id", requireAuth, asyncHandler(async (req, res) => {
    const appointmentId = req.params.id;
    const sapId = req.user.sap_id;

    const [result] = await pool.query(
        "UPDATE appointments SET status = 'Cancelled' WHERE id = ? AND sap_id = ? AND status = 'Pending'",
        [appointmentId, sapId]
    );

    if (result.affectedRows === 0) {
        return res.status(400).json({ error: "Cannot cancel. Appointment not found or already processed." });
    }

    res.json({ success: true, message: "Appointment cancelled." });
}));

module.exports = router;