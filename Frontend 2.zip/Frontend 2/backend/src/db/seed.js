const bcrypt = require("bcrypt");

/**
 * Seeds demo users if they don't already exist.
 * This is meant for development so the existing HTML pages work immediately.
 *
 * Passwords are controlled via env vars (fallback to dev defaults).
 */
async function seedDemoData(pool) {
  const defaultDoctorPassword = process.env.SEED_DOCTOR_PASSWORD || "Doctor123!";
  const defaultAdminPassword = process.env.SEED_ADMIN_PASSWORD || "Admin123!";

  // Best-effort schema alignment for older DBs.
  // If your database was created before we added `specialization` or before we standardized on
  // `password_hash`, this will prevent runtime failures.
  try {
    const [specCols] = await pool.query("SHOW COLUMNS FROM users LIKE 'specialization'");
    if (!specCols.length) {
      await pool.query("ALTER TABLE users ADD COLUMN specialization VARCHAR(100) NULL");
    }

    const [pwHashCols] = await pool.query("SHOW COLUMNS FROM users LIKE 'password_hash'");
    if (!pwHashCols.length) {
      const [pwCols] = await pool.query("SHOW COLUMNS FROM users LIKE 'password'");
      if (pwCols.length) {
        await pool.query("ALTER TABLE users CHANGE password password_hash VARCHAR(255) NOT NULL");
      }
    }
  } catch (err) {
    // Don't fail server startup if schema alignment fails; endpoints may still work.
    // eslint-disable-next-line no-console
    console.warn("[SEED] Schema alignment warning:", err?.message || err);
  }

  const doctors = [
    {
      sap_id: "DOC_GENERAL_001",
      full_name: "General Doctor",
      email: "general.doctor@example.com",
      specialization: "General Doctor",
      role: "doctor",
    },
    {
      sap_id: "DOC_MALE_001",
      full_name: "Nazneen Raimalwala",
      email: "male.counselor@example.com",
      specialization: "Male Counselor",
      role: "doctor",
    },
    {
      sap_id: "DOC_FEMALE_001",
      full_name: "Supriya Khade",
      email: "female.counselor@example.com",
      specialization: "Female Counselor",
      role: "doctor",
    },
  ];

  // Seed doctors (only if missing).
  // Use email uniqueness if present; otherwise sap_id is unique anyway.
  for (const d of doctors) {
    // eslint-disable-next-line no-await-in-loop
    const [existing] = await pool.query("SELECT id FROM users WHERE sap_id = ? OR email = ? LIMIT 1", [
      d.sap_id,
      d.email,
    ]);

    if (existing.length) continue;

    const passwordHash = await bcrypt.hash(defaultDoctorPassword, 10);
    await pool.query(
      "INSERT INTO users (sap_id, full_name, email, password_hash, role, specialization) VALUES (?, ?, ?, ?, ?, ?)",
      [d.sap_id, d.full_name, d.email, passwordHash, d.role, d.specialization]
    );
  }

  // Seed admin (only if missing).
  const admin = {
    sap_id: "ADMIN_001",
    full_name: "Administrator",
    email: "admin@example.com",
    role: "admin",
  };

  const [adminExisting] = await pool.query("SELECT id FROM users WHERE sap_id = ? OR email = ? LIMIT 1", [
    admin.sap_id,
    admin.email,
  ]);

  if (!adminExisting.length) {
    const passwordHash = await bcrypt.hash(defaultAdminPassword, 10);
    await pool.query(
      "INSERT INTO users (sap_id, full_name, email, password_hash, role, specialization) VALUES (?, ?, ?, ?, ?, NULL)",
      [admin.sap_id, admin.full_name, admin.email, passwordHash, admin.role]
    );
  }
}

module.exports = { seedDemoData };

