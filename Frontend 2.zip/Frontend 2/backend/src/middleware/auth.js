const jwt = require("jsonwebtoken");

/**
 * Middleware to verify the JWT token and protect routes.
 * It checks for the 'Authorization: Bearer <token>' header.
 */
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  // Check if header exists and starts with 'Bearer '
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Access denied. No token provided." });
  }

  const token = authHeader.split(" ")[1];

  try {
    const secret = process.env.JWT_SECRET || "dev_jwt_secret_change_me";
    
    // Verify token
    const payload = jwt.verify(token, secret);
    
    // Attach user data (userId, sap_id, role) to the request object
    req.user = payload; 
    
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token. Please login again." });
  }
}

module.exports = {
  requireAuth,
};